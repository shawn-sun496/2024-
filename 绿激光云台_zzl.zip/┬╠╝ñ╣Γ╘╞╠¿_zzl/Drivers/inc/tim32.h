#ifndef __TIM32_H
#define __TIM32_H
#include "driverlib.h"

void Tim32_0_Int_Init(uint32_t aar);
// void Tim32_1_Int_Init(uint32_t aar);

#endif
