#ifndef __PWM_H__
#define __PWM_H__

#include "driverlib.h"

#define TA1_ch0 TIMER_A_CAPTURECOMPARE_REGISTER_0
#define TA1_ch1 TIMER_A_CAPTURECOMPARE_REGISTER_1
#define TA1_ch2 TIMER_A_CAPTURECOMPARE_REGISTER_2
#define TA1_ch3 TIMER_A_CAPTURECOMPARE_REGISTER_3
#define TA1_ch4 TIMER_A_CAPTURECOMPARE_REGISTER_4

void TIM_A1_PWM_Init(uint16_t tax_chn, uint16_t arr, uint16_t duty);
void Set_PWM(uint16_t tax_chn, uint16_t pwm);

#endif
