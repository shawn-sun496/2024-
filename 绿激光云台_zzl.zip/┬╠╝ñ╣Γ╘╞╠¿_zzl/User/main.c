#include "driverlib.h"
#include "delay.h"
#include "led.h"
#include "pwm.h"
#include "servo.h"
#include "tim32.h"
#include "key.h"
#include "oled.h"
#include "usart2.h"
#include "pid.h"
#include "math.h"

/* 引脚 */
/*
    x舵机pwm -- P7.7 TA1_ch1 橙色
    y舵机pwm -- P7.6 TA1_ch2 蓝色 

    OLED SCL P8.5
         SDA P8.6

    USART TX P3.3 接其它的RX
          RX P3.2 接其它的TX

*/

#define _TIM32_DIV_ 480000 		//10ms 100Hz 480000
#define XA 		190.01 					//区域X方向边长，	A坐标系（视觉）
#define YA 		190.01 					//区域Y方向边长，	A坐标系（视觉）
#define _XA 	56.01 					//X方向偏移，			A坐标系（视觉）
#define _YA 	15.01 					//Y方向偏移，			A坐标系（视觉）
#define XB 		29.1 						//区域X方向边长，	B坐标系（舵机）
#define YB 		28.6 						//区域Y方向边长，	B坐标系（舵机）
#define _XB 	75.41//74.3 		//X方向偏移，			B坐标系（舵机）
#define _YB 	77.81//77.01 		//Y方向偏移，			B坐标系（舵机）

extern int start_flag;
extern int mode;

float Target_X = 0, Target_Y = 0; 		//目标为红绿激光点x，y坐标差值都为0
extern uint8_t Current_X,Current_Y;		//红绿激光坐标差值（经过除以4加128处理）
PID_InitDefStruct PID_Struct_X; 			//X轴PID结构体
PID_InitDefStruct PID_Struct_Y; 			//Y轴PID结构体
float X_Angle=90,Y_Angle=90;

float Turn_X,Turn_Y; 												//当前坐标变换后的坐标值
float Last_Turn_X = 90,Last_Turn_Y = 90; 		//上一次坐标变换后的坐标值

//函数声明
void Line(float x_1,float y_1,float x_2,float y_2);
void Axis_Turn(void);
void Init(void);

int main(void)
{
    /* 初始化 */
    Init();
    delay_ms(500);//启动延时
    /* 待启动 */
    while(!start_flag)
    {
       ;
    } // 等待启动
    delay_ms(500);//启动延时    

    while(start_flag)
    {
			//顺时针沿黑色内框
//			Line(103.41,105.59,74.31,105.01);
//			Line(74.31,105.01,77.51,77.41);
//			Line(77.51,77.41,103.41,77.01);
//			Line(103.41,77.01,103.41,105.59);			
			
			
			//顺时针沿视觉识别A4靶(坐标对应版)
//			Axis_Turn();
//			Line(Last_Turn_X,Last_Turn_Y,Turn_X,Turn_Y);
//			Last_Turn_X = Turn_X;
//			Last_Turn_Y = Turn_Y;
			
			//绿激光追踪红激光,放在了中断里
			
			
			OLED_ShowSignedNum(0,1,(int)Current_X,5,8);
      OLED_ShowSignedNum(0,2,(int)Current_Y,5,8);

		}

    /* 停止 */
    /* 结束 */
    while (1);
}


/* 画线函数*/
/*给定起始坐标x_1，y_1和终止坐标x_2，y_2，据此画直线 */
void Line(float x_1,float y_1,float x_2,float y_2)
{
	float step;
	step = 2*(float)sqrt((float)(x_2-x_1)*(float)(x_2-x_1)+(float)(y_2-y_1)*(float)(y_2-y_1)); 		//勾股定理算线段距离
	for(int i = 0; i< (int)(step+1); i++)
	{
		Servo_SetXY((x_1*step+i*(x_2-x_1))/step,(y_1*step+i*(y_2-y_1))/step);	
		delay_ms(2000.0/step);		
	}
}


/* 坐标转化函数（线性粗略对应版）*/
/*将摄像头坐标【Current_X，Current_Y】	转换为	舵机角度坐标【Turn_X，Turn_Y】 */
void Axis_Turn(void)
{
	//这两句表达式是从线性表达式一步步推的
	Turn_X = (XB*XA-XB*Current_X+XB*_XA+XA*_XB)/XA	;	
	Turn_Y = (YB*YA-YB*Current_Y+YB*_YA+YA*_YB)/YA	;		
}


	
/* 初始化函数 */
void Init(void)
{
    /* 滴答延时初始化 */
    Delay_Init();
    /* LED初始化 */
    LED_Init();
    /* 按键初始化 */
    Key_Init();
    /* OLED初始化 */
    OLED_Init();
    OLED_Clear();
    /* 串口2初始化 */
    UART2_Init(115200);
    /* xy舵机初始化 */
    Servo_Init();
		Servo_SetXY(90,91);	

    /* TIM32定时器初始化 */
    Tim32_0_Int_Init(_TIM32_DIV_);
		/* xy舵机PID初始化*/
		/*参数：Kp,Ki,Kd		,上次误差，上上次误差，	积分累加，输出下限，输出上限，out*/
    PID_Init(&PID_Struct_X,10,0,0		,0,0		,0,10,-10,0);//x轴PID初始化 
    PID_Init(&PID_Struct_Y,10,0,0		,0,0		,0,10,-10,0);//y轴PID初始化
}



/* TIMER32_0_BASE的中断服务函数 */
/* 10ms进入一次中断 */
void T32_INT1_IRQHandler(void)
{
    Timer32_clearInterruptFlag(TIMER32_0_BASE);//清除中断标志位
	
    PID_Control_D(Target_X,(float)(Current_X - 128),&PID_Struct_X);
    PID_Control_D(Target_Y,(float)(Current_Y - 128),&PID_Struct_Y);
	  
		//绿激光默认位置在90°，90°
    X_Angle = 90 - PID_Struct_X.Output;  
    Y_Angle = 90 - PID_Struct_Y.Output;
	  Servo_SetXY(X_Angle,Y_Angle);
}
