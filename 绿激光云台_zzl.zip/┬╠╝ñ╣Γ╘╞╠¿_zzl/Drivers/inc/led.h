#ifndef __LED_H
#define __LED_H

#include "driverlib.h"

// 位带操作
// #define LED_RED BITBAND_PERI(P1OUT,0)

void LED_Init(void);
void LED_RED_On(void);
void LED_RED_Off(void);

#endif
