#ifndef __SERVO_H__
#define __SERVO_H__

#include "driverlib.h"

void Servo_Init(void);
void Servo_SetAngle(uint16_t tax_chn, float Angle);
void Servo_SetXY(float _x_,float _y_);

#endif
