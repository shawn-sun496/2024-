#include "servo.h"
#include "pwm.h"

/*
     x舵机      P7.7 
     y舵机      P7.6 
*/

void Servo_Init(void)
{
	TIM_A1_PWM_Init(TA1_ch1, 20000, 1500);//x舵机pwm初始化 50Hz 占空比2.5% pwm取值500~2500
  TIM_A1_PWM_Init(TA1_ch2, 20000, 1500);
}

void Servo_SetAngle(uint16_t tax_chn, float Angle)
{
    uint16_t _pwm_= (uint16_t)(Angle*2000/180+500);
    Set_PWM(tax_chn, _pwm_);
}

void Servo_SetXY(float _x_,float _y_)
{
    Servo_SetAngle(TA1_ch1, _x_);
    Servo_SetAngle(TA1_ch2, _y_);
}
