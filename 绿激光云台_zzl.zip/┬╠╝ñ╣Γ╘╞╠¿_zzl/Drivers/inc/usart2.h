#ifndef __USART2_H
#define __USART2_H

#include "driverlib.h"
#include "stdio.h"

void UART2_Init(uint32_t baudRate);
void Copy_Recv_Data(void);

#endif
