#ifndef __KEY_H
#define __KEY_H 			   

#include "driverlib.h"

void Key_Init(void);

#endif
