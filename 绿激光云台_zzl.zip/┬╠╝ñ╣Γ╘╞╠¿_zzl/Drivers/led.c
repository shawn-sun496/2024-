#include "led.h"

void LED_Init(void)
{
    GPIO_setAsOutputPin(GPIO_PORT_P1,GPIO_PIN0);
    LED_RED_Off();
}
void LED_RED_On(void){GPIO_setOutputHighOnPin(GPIO_PORT_P1,GPIO_PIN0);}
void LED_RED_Off(void){GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0);}
