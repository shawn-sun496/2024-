#include "usart2.h"
#include "baudrate_calculate.h"

int Rxstate = 0;
int Buff_Index = 0;

uint8_t DataBuff_xy[2];//x坐标和y坐标
uint8_t Current_X=0,Current_Y=0;

#pragma import(__use_no_semihosting)
//标准库需要的支持函数
struct __FILE
{
  int handle;
};
FILE __stdout;

int fputc(int ch, FILE *f)
{
  UART_transmitData(EUSCI_A2_BASE, ch & 0xFF);
  return ch;
}

void UART2_Init(uint32_t baudRate)
{
  //固件库v3_40_01_02
  //默认SMCLK 48MHz 比特率 115200
  const eUSCI_UART_ConfigV1 uartConfig =
      {
          EUSCI_A_UART_CLOCKSOURCE_SMCLK,                // SMCLK Clock Source
          26,                                            // BRDIV = 26
          0,                                             // UCxBRF = 0
          111,                                           // UCxBRS = 111
          EUSCI_A_UART_NO_PARITY,                        // No Parity
          EUSCI_A_UART_LSB_FIRST,                        // MSB First
          EUSCI_A_UART_ONE_STOP_BIT,                     // One stop bit
          EUSCI_A_UART_MODE,                             // UART mode
          EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION, // Oversampling
          EUSCI_A_UART_8_BIT_LEN                         // 8 bit data length
      };
  eusci_calcBaudDividers((eUSCI_UART_ConfigV1 *)&uartConfig, baudRate); //配置波特率

  GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P3, GPIO_PIN3, GPIO_PRIMARY_MODULE_FUNCTION);//TX
  GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P3, GPIO_PIN2, GPIO_PRIMARY_MODULE_FUNCTION);//RX
  UART_initModule(EUSCI_A2_BASE, &uartConfig);
  UART_enableModule(EUSCI_A2_BASE);
  UART_enableInterrupt(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
  Interrupt_enableInterrupt(INT_EUSCIA2);
}

void Copy_Recv_Data(void)
{
    int receiveData = 0;
    receiveData = UART_receiveData(EUSCI_A2_BASE);
    if(receiveData == 0xfe && Rxstate == 0) Rxstate = 1;//接收到帧头
    else if(Rxstate == 1)
    {
        if(receiveData == 0xff)//接收到帧尾
        {
            Rxstate = 0;
            Buff_Index = 0;
            Current_X=DataBuff_xy[0];Current_Y=DataBuff_xy[1];
            DataBuff_xy[0]='\0';DataBuff_xy[1]='\0';
        }
        else //接收xy
        {
             DataBuff_xy[Buff_Index]=receiveData;
             Buff_Index++;
        }
        UCA2RXBUF = 0;
    }
    else
    {
         Rxstate = 0;
         Buff_Index = 0;
    }
}

void EUSCIA2_IRQHandler(void)
{
    switch(UCA2IV)
    {
        case 2:
            Copy_Recv_Data();//处理数据
            break;
        default:break;
    }
}
