#include "key.h"
#include "delay.h"

int start_flag = 0;
int mode = 5;

/* 按键外部中断初始化 */
void Key_Init(void)
{
	//配置引脚
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1,GPIO_PIN4);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1,GPIO_PIN1);
	//配置中断
	GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN1);
	GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN1);
	//开启GPIO_PORT中断
	Interrupt_enableInterrupt(INT_PORT1);
	//使能总中断控制器
	Interrupt_enableMaster();
}


/* 外部中断服务函数*/
/* 中断服务函数，在中断内处理程序 */
void PORT1_IRQHandler(void)
{
    uint16_t flag;
    /*获取中断状态*/
    flag = GPIO_getEnabledInterruptStatus(GPIO_PORT_P1);
    /* 启动按键 */
    if (flag & GPIO_PIN4)
    {
        delay_ms(500); 
        start_flag=1-start_flag;
    }
    /* 按键S2 */
    if (flag & GPIO_PIN1)
    {
        delay_ms(500); 
        switch(mode)
        {
            case 9:mode=1;break;
            default:mode++;break;
        }
    }
    /*清除中断标志位*/
    GPIO_clearInterruptFlag(GPIO_PORT_P1, flag);
}
