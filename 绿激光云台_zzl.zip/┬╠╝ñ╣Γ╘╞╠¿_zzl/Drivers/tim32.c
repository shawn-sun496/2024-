#include "tim32.h"

/* 定时器32_0 */
void Tim32_0_Int_Init(uint32_t aar)
{
    Timer32_initModule(TIMER32_0_BASE, TIMER32_PRESCALER_1, TIMER32_32BIT, TIMER32_PERIODIC_MODE);  //32位周期计数模式
    Timer32_setCount(TIMER32_0_BASE, aar);                                          //设置ARR自动重装载值
    Timer32_startTimer(TIMER32_0_BASE, false);                                      //配置定时器32开始连续计数 //连续计数模式选false
    Timer32_clearInterruptFlag(TIMER32_0_BASE);                                     //清除中断标志位
    Timer32_enableInterrupt(TIMER32_0_BASE);                                        //使能定时器32_0中断
    Interrupt_enableInterrupt(INT_T32_INT1);                                        //开启定时器32_0端口中断
}

// /* 定时器32_1 */
// void Tim32_1_Int_Init(uint32_t aar)
// {
//     Timer32_initModule(TIMER32_1_BASE, TIMER32_PRESCALER_16, TIMER32_32BIT, TIMER32_PERIODIC_MODE);
//     Timer32_setCount(TIMER32_1_BASE, aar);
//     Timer32_startTimer(TIMER32_1_BASE, false);
//     Timer32_clearInterruptFlag(TIMER32_1_BASE);
//     Timer32_enableInterrupt(TIMER32_1_BASE);
//     Interrupt_enableInterrupt(INT_T32_INT2);
// }

/* TIMER32_1_BASE的中断服务函数 */
// void T32_INT2_IRQHandler(void)
// {
//     Timer32_clearInterruptFlag(TIMER32_1_BASE);

//     /*开始填充用户代码*/
//     /*结束填充用户代码*/
// }
