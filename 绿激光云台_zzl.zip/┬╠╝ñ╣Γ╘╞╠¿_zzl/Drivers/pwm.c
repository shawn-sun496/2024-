#include "pwm.h"

/***************************************************************************************************
//  @brief      设置PWM
//  @param      tax_chn        选择通道
//  @param      arr            需要设置的频率        f=48MHz/divider/arr  f=1MHz/20000=50Hz
//  @param      duty           需要设置的占空比      duty/arr
//  @example    TIM_A1_Pwm_Set(TA1_ch2,20000,10000);		//2通道，50HZ，占空比50%
***************************************************************************************************/
void TIM_A1_PWM_Init(uint16_t tax_chn, uint16_t arr, uint16_t duty)
{
    /* 定义结构体 */
    Timer_A_PWMConfig TIM_A1_PWMConfig;
    /* 定时器PWM初始化 */
    TIM_A1_PWMConfig.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;             //时钟源
    TIM_A1_PWMConfig.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_48; //分频系数PSC 48分频 48MHz/48
    TIM_A1_PWMConfig.timerPeriod = arr-1;            					  //计数周期ARR
    TIM_A1_PWMConfig.compareOutputMode = TIMER_A_OUTPUTMODE_RESET_SET;   //输出模式
    TIM_A1_PWMConfig.dutyCycle = duty;     							  //设置占空比
    TIM_A1_PWMConfig.compareRegister = tax_chn;                           //设置通道
    /* 选择通道 */
    switch(tax_chn)
	{
		case TA1_ch1:
			GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P7,GPIO_PIN7,GPIO_PRIMARY_MODULE_FUNCTION);//P7.7 左轮pwm
			break;
		case TA1_ch2:
			GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P7,GPIO_PIN6,GPIO_PRIMARY_MODULE_FUNCTION);//P7.6 右轮pwm
			break;
		default:break;
	}
    Timer_A_generatePWM(TIMER_A1_BASE, &TIM_A1_PWMConfig); // 初始化比较寄存器以产生 PWM 
}

void Set_PWM(uint16_t tax_chn, uint16_t pwm)
{
	switch(tax_chn)
	{
		case TA1_ch1:
		case TA1_ch2:
		case TA1_ch3:
		case TA1_ch4:
			Timer_A_setCompareValue(TIMER_A1_BASE, tax_chn, pwm);
			break;
		default:break;
	}
}
